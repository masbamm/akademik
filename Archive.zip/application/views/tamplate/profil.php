

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
    
 <!-- <div>
    <img src="<?php echo base_url() ?>assets/images/logo1.jpg" alt="" width="800" height="180px">
    <div class="card-body">     
  </div>  -->
  
<nav class="navbar navbar-expand-lg navbar-light bg-light">
     
     <div class="collapse navbar-collapse d-flex justify-content-center" id="navbarNav">
      <ul class="navbar-nav">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo base_url('admin'); ?>">Home</a>
           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
           <span class="navbar-toggler-icon"></span>
          </button>
          
        <li class="nav-item" >
          <a class="nav-link" href="<?php echo base_url('profil/profil'); ?>">Profil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('kontak/kontak'); ?>">Kontak</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo base_url('galeri/galeri'); ?>">Galeri</a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link " aria-current="page" href="<?php echo base_url('kelas/index'); ?>">Foto</a>
        </li>
        <li class="nav-item">
          <a class="nav-link " aria-current="page" href="<?php echo base_url('guru_matapelajaran/index'); ?>">prestasi</a>
        </li> -->
       </ul>
     </div>
     </div>
  </nav><br><br>