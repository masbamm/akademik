<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
	<title>profil </title>
	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
   	 <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet"/>
   	 <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/style.css">
</head>
<body>

	<div class="bg-info">
		<div class="container py-5">
			<div class="card bg-white p-4">
				<div class="text-center position-absolute bg-opacity-3" style="z-index:1; opacity: 0.2">

					
				</div>
				<div style="z-index:2;">
					
					<div class="row">
						<div class="col-sm-4">
							<img src="<?php echo base_url() ?>assets/images/kesenian/a.jpeg" alt="" width="400" height="250px">
						</div>

						<div class="col-sm-3"></div>
					
						<div class="col-sm-4">
							<img src="<?php echo base_url() ?>assets/images/kesenian/b.jpeg" alt="" width="400" height="250px">
						</div>
					</div><br>

					<div class="row">
						<div class="col-sm-4">
							<img src="<?php echo base_url() ?>assets/images/kesenian/c.jpeg" alt="" width="400" height="250px">
						</div>

						<div class="col-sm-3"></div>
					
						<div class="col-sm-4">
							<img src="<?php echo base_url() ?>assets/images/kesenian/d.jpeg" alt="" width="400" height="250px">
						</div>
					</div>





					
				</div>
				
			</div>
			
		</div>
		
	</div>

	

</body>
</html>